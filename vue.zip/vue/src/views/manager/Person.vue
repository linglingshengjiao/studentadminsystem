<template>
<div>
  <div class="card" style="width:50%;padding:50px 40px">
    <el-form :model="data.form" label-width="100px" label-position="right" style="padding-right: 25px" ref="formRef" >
      <el-form-item label="图片">
       <el-upload class="avatar-uploader" action="http://localhost:9090/files/upload" :show-file-list="false"
                  :on-success="handleImgUploadSuccess">
         <img v-if="data.form.picture" :src="data.form.picture" class="avatar" />
         <el-icon v-else class="avatar-uploader-icon"><Plus /></el-icon>
       </el-upload>
      </el-form-item>
      <el-form-item label="学号" prop="username">
        <el-input v-model="data.form.username" autocomplete="off" disabled/>
      </el-form-item>
      <el-form-item label="姓名">
        <el-input v-model="data.form.name" autocomplete="off" />
      </el-form-item>
      <el-form-item label="手机号码">
        <el-input v-model="data.form.phone" autocomplete="off" />
      </el-form-item>
      <el-form-item label="密码" prop="password">
        <el-input show-password v-model="data.form.password" autocomplete="off" />
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click = "save">保存</el-button>
      </el-form-item>
     </el-form>

  </div>
</div>
</template>


<script setup>
  import {reactive,ref} from "vue";
  import request from "@/utils/request";
  import {ElMessage} from "element-plus";
  import router from "@/router";
  import {Plus} from '@element-plus/icons-vue'

  const data = reactive({
    form:JSON.parse(localStorage.getItem('student-user') || "{}")
  })

  const handleImgUploadSuccess = (res) =>{
    data.form.picture = res.data
  }

  const save =()=>{
    request.put('/student/update', data.form).then(res => {
      if(res.code === '200'){
        ElMessage.success("保存成功")
        router.push('/login')
      }
      else{
        ElMessage.error(res.msg)
      }
    })
  }



</script>

<style>
.avatar-uploader .el-upload {
  border: 1px dashed var(--el-border-color);
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  transition: var(--el-transition-duration-fast);
}
.avatar-uploader .el-upload:hover {
  border-color: var(--el-color-primary);
}
.avatar{
  width:160px;
  height:200px;
}

.el-icon.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 160px;
  height: 200px;
  text-align: center;
}
</style>
