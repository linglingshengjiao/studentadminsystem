<template>
  <div>
    <div class="card" style="margin-bottom: 10px">
      <el-input style="width: 260px; margin-left: 10px" v-model="data.courseName"  placeholder="输入课程名称查询" :prefix-icon="Search"/>
      <el-input style="width: 260px; margin-left: 10px" v-model="data.studentName" placeholder="输入学生姓名查询" :prefix-icon="Search"/>
      <el-button type="info" style="margin-left: 10px" @click="load">查询</el-button>
      <el-button type="info" @click="reset">重置</el-button>
    </div>

    <div>
      <el-table :data="data.tableData" style="width: 100%">
        <el-table-column prop="id" label="序号" width="100" />
        <el-table-column prop="courseName" label="名称" />
        <el-table-column prop="studentName" label="选课人" />
        <el-table-column prop="score" label="分数" />
        <el-table-column prop="comment" label="评语" />
        <el-table-column>
          <template #default="scope">
            <el-button type="warning" @click="handleEdit(scope.row)" v-if="data.user.role === 'ADMIN'">修改</el-button>
            <el-button type="danger" @click="del(scope.row.id)" v-if="data.user.role==='ADMIN'">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>

    <div class="card">
      <el-pagination v-model:current-page="data.pageNum" v-model:page-size="data.pageSize"
                     @current-change="handleCurrentChange"
                     background layout="prev, pager, next" :total="data.total" />
    </div>

    <el-dialog v-model="data.formVisible" title="成绩信息" width="500">
      <el-form :model="data.form" label-width="100px" label-position="right" style="padding-right: 25px">
        <el-form-item label="课程名称">
          <el-input v-model="data.form.courseName" autocomplete="off" disabled/>
        </el-form-item>
        <el-form-item label="课程分数">
          <el-input v-model="data.form.score" autocomplete="off"/>
        </el-form-item>
        <el-form-item label="备注">
          <el-input v-model="data.form.comment" autocomplete="off"/>
        </el-form-item>
      </el-form>
      <template #footer>
      <div class="dialog-footer">
        <el-button @click="data.formVisible = false">取消</el-button>
        <el-button type="info" @click="save">保存</el-button>
      </div>
      </template>
    </el-dialog>

  </div>
</template>

<script setup>
import {reactive} from "vue";
import {Search} from '@element-plus/icons-vue'
import request from "@/utils/request";
import {ElMessage, ElMessageBox} from "element-plus";

const data =reactive({
  form:{},
  courseName: '',
  studentName:'',
  tableData: [],
  total: 0,
  pageNum: 1, //当前页码
  pageSize: 10, //每页个数
  user:JSON.parse(localStorage.getItem('student-user')||'{}'),
  formVisible:false
})

const load = () => {
  let params = {
    pageNum:data.pageNum,
    pageSize:data.pageSize,
    courseName:data.courseName,
    studentName:data.studentName,
  }
  if(data.user.role==='STUDENT'){
    params.studentId = data.user.id
  }
  request.get('/grade/selectPage',{
    params: params
  }).then(res =>{
    data.tableData=res.data?.list || []
    data.total=res.data?.total || 0
  })
}

load()

const handleCurrentChange =()=>{
  load()
}

const del=(id)=>{
  ElMessageBox.confirm('删除后不可恢复','确认删除',{type:'warning'}).then(res=>{
    request.delete('/grade/delete/'+id).then(res => {
      if (res.code === '200') {
        load()//重新获取
        ElMessage.success("删除成功")
      } else {
        ElMessage.error(res.msg)
      }
    })
  }).catch(res => {
    ElMessage({
      type:'info',
      message:'已取消'
    })
  })
}

const reset=()=>{
  data.courseNamename=''
  data.studentName=''
  load()
}

const save=()=>{
  request.put('/grade/update',data.form).then(res=>{
    if(res.code === '200'){
      data.formVisible=false
      ElMessage.success("保存成功")
      load();
    }
    else{
      ElMessage.error(res.msg)
    }
  })
}

const handleEdit = (row) => {
  data.form=JSON.parse(JSON.stringify(row))
  data.formVisible=true

}

</script>