import { first } from "../fp";
export = first;
