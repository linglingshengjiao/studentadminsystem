import { isTypedArray } from "../fp";
export = isTypedArray;
