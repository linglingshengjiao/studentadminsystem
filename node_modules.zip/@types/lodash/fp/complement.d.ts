import { complement } from "../fp";
export = complement;
