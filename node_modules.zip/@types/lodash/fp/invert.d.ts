import { invert } from "../fp";
export = invert;
