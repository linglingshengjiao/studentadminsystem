import { curryRightN } from "../fp";
export = curryRightN;
