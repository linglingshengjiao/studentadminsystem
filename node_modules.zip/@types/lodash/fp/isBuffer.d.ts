import { isBuffer } from "../fp";
export = isBuffer;
