import { lt } from "../fp";
export = lt;
