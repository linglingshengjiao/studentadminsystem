import { conforms } from "../fp";
export = conforms;
