import { maxBy } from "../fp";
export = maxBy;
