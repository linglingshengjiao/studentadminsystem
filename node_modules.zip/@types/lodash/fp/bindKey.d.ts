import { bindKey } from "../fp";
export = bindKey;
