import { functionsIn } from "../fp";
export = functionsIn;
