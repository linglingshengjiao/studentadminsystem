import { assignInWith } from "../fp";
export = assignInWith;
