import { cond } from "./index";
export = cond;
