# Installation
> `npm install --save @types/lodash`

# Summary
This package contains type definitions for lodash (https://lodash.com).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/lodash.

### Additional Details
 * Last updated: Tue, 07 Nov 2023 20:08:00 GMT
 * Dependencies: none

# Credits
These definitions were written by [Brian Zengel](https://github.com/bczengel), [Ilya Mochalov](https://github.com/chrootsu), [AJ Richardson](https://github.com/aj-r), [e-cloud](https://github.com/e-cloud), [Georgii Dolzhykov](https://github.com/thorn0), [Jack Moore](https://github.com/jtmthf), [Dominique Rau](https://github.com/DomiR), and [William Chelman](https://github.com/WilliamChelman).
