import { flatMapDeep } from "./index";
export = flatMapDeep;
