import { concat } from "./index";
export = concat;
