import { capitalize } from "./index";
export = capitalize;
