import type { Rect, Strategy } from '@floating-ui/core';
export declare function getViewportRect(element: Element, strategy: Strategy): Rect;
