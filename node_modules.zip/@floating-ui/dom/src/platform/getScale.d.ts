import type { Coords } from '@floating-ui/core';
import type { VirtualElement } from '../types';
export declare function getScale(element: Element | VirtualElement): Coords;
