export declare function isRTL(element: Element): boolean;
