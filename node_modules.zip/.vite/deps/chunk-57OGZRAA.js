// node_modules/element-plus/es/components/popper/style/index.mjs
import "D:/ACsoftware/student/vue/node_modules/element-plus/theme-chalk/src/popper.scss";
//# sourceMappingURL=chunk-57OGZRAA.js.map
