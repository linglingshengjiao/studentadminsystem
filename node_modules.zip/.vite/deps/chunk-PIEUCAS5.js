// node_modules/element-plus/es/components/option-group/style/index.mjs
import "D:/ACsoftware/student/vue/node_modules/element-plus/theme-chalk/src/option-group.scss";

// node_modules/element-plus/es/components/select/style/index.mjs
import "D:/ACsoftware/student/vue/node_modules/element-plus/theme-chalk/src/select.scss";
//# sourceMappingURL=chunk-PIEUCAS5.js.map
