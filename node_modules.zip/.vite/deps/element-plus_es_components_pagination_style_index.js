import "./chunk-PIEUCAS5.js";
import "./chunk-5PU2ZVKM.js";
import "./chunk-HYOCXO5I.js";
import "./chunk-2L7WQUCN.js";
import "./chunk-EPZZXICQ.js";
import "./chunk-57OGZRAA.js";
import "./chunk-LXTKWTJN.js";

// node_modules/element-plus/es/components/pagination/style/index.mjs
import "D:/ACsoftware/student/vue/node_modules/element-plus/theme-chalk/src/pagination.scss";
//# sourceMappingURL=element-plus_es_components_pagination_style_index.js.map
