import "./chunk-LXTKWTJN.js";

// node_modules/element-plus/es/components/badge/style/index.mjs
import "D:/ACsoftware/student/vue/node_modules/element-plus/theme-chalk/src/badge.scss";

// node_modules/element-plus/es/components/message/style/index.mjs
import "D:/ACsoftware/student/vue/node_modules/element-plus/theme-chalk/src/message.scss";
//# sourceMappingURL=element-plus_es_components_message_style_index.js.map
