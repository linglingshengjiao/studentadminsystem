// node_modules/element-plus/es/components/scrollbar/style/index.mjs
import "D:/ACsoftware/student/vue/node_modules/element-plus/theme-chalk/src/scrollbar.scss";
//# sourceMappingURL=chunk-HYOCXO5I.js.map
