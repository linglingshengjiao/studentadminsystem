import "./chunk-LXTKWTJN.js";

// node_modules/element-plus/es/components/form/style/index.mjs
import "D:/ACsoftware/student/vue/node_modules/element-plus/theme-chalk/src/form.scss";
//# sourceMappingURL=element-plus_es_components_form_style_index.js.map
