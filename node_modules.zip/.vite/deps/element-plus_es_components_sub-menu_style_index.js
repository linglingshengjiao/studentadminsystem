import "./chunk-LXTKWTJN.js";

// node_modules/element-plus/es/components/sub-menu/style/index.mjs
import "D:/ACsoftware/student/vue/node_modules/element-plus/theme-chalk/src/sub-menu.scss";
//# sourceMappingURL=element-plus_es_components_sub-menu_style_index.js.map
