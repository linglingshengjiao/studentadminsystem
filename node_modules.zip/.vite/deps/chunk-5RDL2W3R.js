// node_modules/element-plus/es/components/button/style/index.mjs
import "D:/ACsoftware/student/vue/node_modules/element-plus/theme-chalk/src/button.scss";
//# sourceMappingURL=chunk-5RDL2W3R.js.map
