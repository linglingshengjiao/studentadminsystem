import "./chunk-LXTKWTJN.js";

// node_modules/element-plus/es/components/upload/style/index.mjs
import "D:/ACsoftware/student/vue/node_modules/element-plus/theme-chalk/src/upload.scss";

// node_modules/element-plus/es/components/progress/style/index.mjs
import "D:/ACsoftware/student/vue/node_modules/element-plus/theme-chalk/src/progress.scss";
//# sourceMappingURL=element-plus_es_components_upload_style_index.js.map
