// node_modules/element-plus/es/components/checkbox/style/index.mjs
import "D:/ACsoftware/student/vue/node_modules/element-plus/theme-chalk/src/checkbox.scss";
//# sourceMappingURL=chunk-7ZF4JBBV.js.map
