import "./chunk-LXTKWTJN.js";

// node_modules/element-plus/es/components/menu-item/style/index.mjs
import "D:/ACsoftware/student/vue/node_modules/element-plus/theme-chalk/src/menu-item.scss";
//# sourceMappingURL=element-plus_es_components_menu-item_style_index.js.map
