// node_modules/element-plus/es/components/option/style/index.mjs
import "D:/ACsoftware/student/vue/node_modules/element-plus/theme-chalk/src/option.scss";
//# sourceMappingURL=chunk-5PU2ZVKM.js.map
