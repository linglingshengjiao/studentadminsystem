import "./chunk-LXTKWTJN.js";

// node_modules/element-plus/es/components/image/style/index.mjs
import "D:/ACsoftware/student/vue/node_modules/element-plus/theme-chalk/src/image.scss";

// node_modules/element-plus/es/components/image-viewer/style/index.mjs
import "D:/ACsoftware/student/vue/node_modules/element-plus/theme-chalk/src/image-viewer.scss";
//# sourceMappingURL=element-plus_es_components_image_style_index.js.map
