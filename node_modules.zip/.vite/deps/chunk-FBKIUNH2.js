// node_modules/element-plus/es/components/tooltip/style/index.mjs
import "D:/ACsoftware/student/vue/node_modules/element-plus/theme-chalk/src/tooltip.scss";
//# sourceMappingURL=chunk-FBKIUNH2.js.map
