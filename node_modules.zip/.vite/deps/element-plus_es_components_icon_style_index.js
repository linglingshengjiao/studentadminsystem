import "./chunk-LXTKWTJN.js";

// node_modules/element-plus/es/components/icon/style/index.mjs
import "D:/ACsoftware/student/vue/node_modules/element-plus/theme-chalk/src/icon.scss";
//# sourceMappingURL=element-plus_es_components_icon_style_index.js.map
