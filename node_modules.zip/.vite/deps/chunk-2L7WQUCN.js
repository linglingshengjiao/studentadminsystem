// node_modules/element-plus/es/components/tag/style/index.mjs
import "D:/ACsoftware/student/vue/node_modules/element-plus/theme-chalk/src/tag.scss";
//# sourceMappingURL=chunk-2L7WQUCN.js.map
