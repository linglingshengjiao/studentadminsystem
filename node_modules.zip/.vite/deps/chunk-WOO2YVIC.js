// node_modules/element-plus/es/components/overlay/style/index.mjs
import "D:/ACsoftware/student/vue/node_modules/element-plus/theme-chalk/src/overlay.scss";
//# sourceMappingURL=chunk-WOO2YVIC.js.map
