declare const _exports: (o: {}, p: PropertyKey) => p is never;
export = _exports;
//# sourceMappingURL=index.d.ts.map