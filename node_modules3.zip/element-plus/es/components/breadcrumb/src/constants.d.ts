import type { InjectionKey } from 'vue';
import type { BreadcrumbProps } from './breadcrumb';
export declare const breadcrumbKey: InjectionKey<BreadcrumbProps>;
