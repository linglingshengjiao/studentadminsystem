import type Alert from './alert.vue';
export declare type AlertInstance = InstanceType<typeof Alert>;
