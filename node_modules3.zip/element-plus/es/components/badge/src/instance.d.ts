import type Badge from './badge.vue';
export declare type BadgeInstance = InstanceType<typeof Badge>;
