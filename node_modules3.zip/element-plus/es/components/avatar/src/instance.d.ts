import type Avatar from './avatar.vue';
export declare type AvatarInstance = InstanceType<typeof Avatar>;
