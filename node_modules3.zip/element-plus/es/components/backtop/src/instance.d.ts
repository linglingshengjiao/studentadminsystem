import type Backtop from './backtop.vue';
export declare type BacktopInstance = InstanceType<typeof Backtop>;
