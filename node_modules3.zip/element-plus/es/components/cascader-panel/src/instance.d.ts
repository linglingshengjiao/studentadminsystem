import type CascaderPanel from './index.vue';
export declare type CascaderPanelInstance = InstanceType<typeof CascaderPanel>;
