import type Card from './card.vue';
export declare type CardInstance = InstanceType<typeof Card>;
