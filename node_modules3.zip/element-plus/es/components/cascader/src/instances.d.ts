import type Cascader from './cascader.vue';
export declare type CascaderInstance = InstanceType<typeof Cascader>;
