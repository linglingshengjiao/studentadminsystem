declare const _default: {
    required: import("..").ExecuteRule;
    whitespace: import("..").ExecuteRule;
    type: import("..").ExecuteRule;
    range: import("..").ExecuteRule;
    enum: import("..").ExecuteRule;
    pattern: import("..").ExecuteRule;
};
export default _default;
