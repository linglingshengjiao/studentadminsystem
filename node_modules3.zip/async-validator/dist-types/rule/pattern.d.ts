import { ExecuteRule } from '../interface';
declare const pattern: ExecuteRule;
export default pattern;
