import { ExecuteRule } from '../interface';
declare const required: ExecuteRule;
export default required;
