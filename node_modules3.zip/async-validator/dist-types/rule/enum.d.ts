import { ExecuteRule } from '../interface';
declare const enumerable: ExecuteRule;
export default enumerable;
