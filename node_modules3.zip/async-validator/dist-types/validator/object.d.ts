import { ExecuteValidator } from '../interface';
declare const object: ExecuteValidator;
export default object;
