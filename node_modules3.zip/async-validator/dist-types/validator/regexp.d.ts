import { ExecuteValidator } from '../interface';
declare const regexp: ExecuteValidator;
export default regexp;
