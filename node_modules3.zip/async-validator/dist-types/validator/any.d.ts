import { ExecuteValidator } from '../interface';
declare const any: ExecuteValidator;
export default any;
