import { ExecuteValidator } from '../interface';
declare const required: ExecuteValidator;
export default required;
