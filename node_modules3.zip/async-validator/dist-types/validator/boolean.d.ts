import { ExecuteValidator } from '../interface';
declare const boolean: ExecuteValidator;
export default boolean;
