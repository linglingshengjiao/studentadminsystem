import { ExecuteValidator } from '../interface';
declare const type: ExecuteValidator;
export default type;
