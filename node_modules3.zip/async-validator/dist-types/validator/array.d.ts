import { ExecuteValidator } from '../interface';
declare const array: ExecuteValidator;
export default array;
