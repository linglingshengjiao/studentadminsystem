import { ExecuteValidator } from '../interface';
declare const date: ExecuteValidator;
export default date;
