package com.example.service;

import com.example.entity.Course;
import com.example.entity.StudentCourse;
import com.example.exception.CustomException;
import com.example.mapper.StudentCourseMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import javax.annotation.Resource;
import java.util.List;

@Service
public class StudentCourseService {

    @Resource
    StudentCourseMapper studentCourseMapper;

    public void deleteById(Integer id) {
        studentCourseMapper.deleteById(id);
    }

    public void add( StudentCourse studentCourse){
        StudentCourse course = studentCourseMapper.selectByCondition(studentCourse);//是否重复选课
        if(course != null){
            throw new CustomException("不可重复选课");
        }
        studentCourseMapper.insert(studentCourse);
    }

    public PageInfo<StudentCourse> selectPage(Integer pageNum, Integer pageSize, StudentCourse studentCourse) {
        PageHelper.startPage(pageNum,pageSize);
        List<StudentCourse> studentCourseList= studentCourseMapper.selectAll(studentCourse);
        return PageInfo.of(studentCourseList);
    }
}
