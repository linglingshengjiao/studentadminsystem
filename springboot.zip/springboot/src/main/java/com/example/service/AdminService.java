package com.example.service;

import com.example.entity.Account;
import com.example.entity.Admin;
import com.example.exception.CustomException;
import com.example.mapper.AdminMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class AdminService {
    @Resource
    private AdminMapper adminMapper;

    public Account login(Account account){
        Account dbAccount=adminMapper.selectByUsername(account.getUsername());
        if(dbAccount == null){//无账号
            throw new CustomException("账号错误");
        }
        if(!account.getPassword().equals(dbAccount.getPassword())){//密码不相等
            throw new CustomException("密码错误");
        }
        //登录成功
        return dbAccount;
    }
}
