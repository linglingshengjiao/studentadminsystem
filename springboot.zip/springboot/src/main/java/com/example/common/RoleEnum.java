package com.example.common;

public enum RoleEnum {
    ADMIN,
    STUDENT
}
