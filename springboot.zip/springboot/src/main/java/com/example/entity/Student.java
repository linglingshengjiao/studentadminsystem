package com.example.entity;

public class Student extends Account{
    private Integer id;
    private String username;
    private String phone;
    private String name;
    private String password;
    private String role;
    private String picture;

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public Integer getId() { return id; }

    public void setId(Integer id) { this.id = id; }

    @Override
    public String getUsername() { return username; }

    @Override
    public void setUsername(String username) { this.username = username; }

    public String getPhone() { return phone; }

    public void setPhone(String phone) { this.phone = phone; }

    @Override
    public String getName() { return name; }

    @Override
    public void setName(String name) { this.name = name; }

    @Override
    public String getPassword() { return password; }

    @Override
    public void setPassword(String password) { this.password = password; }

    @Override
    public String getRole() { return role; }

    @Override
    public void setRole(String role) { this.role = role; }
}
