package com.example.controller;

import com.example.common.Result;
import com.example.entity.Course;
import com.example.service.CourseService;
import com.github.pagehelper.PageInfo;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

@RestController
@RequestMapping("/course")
public class CourseController {
    @Resource
    private CourseService courseService;

    @GetMapping("/selectPage")//表示将处理selectPage路径的Get请求其他同理
    public Result selectPage(@RequestParam(defaultValue = "1") Integer pageNum,//页码数，请求分页数据
                             @RequestParam(defaultValue = "10") Integer pageSize,//页尺寸
                             Course course){
        PageInfo<Course>pageInfo = courseService.selectPage(pageNum,pageSize,course);//调用service方法
        return Result.success(pageInfo);
    }

    @PostMapping("/add")
    public Result add(@RequestBody Course course){//将前端发送转化为course对象，新增
        courseService.add(course);
        return Result.success();//返回成功信息
    }

    @PutMapping("/update")
    public Result update(@RequestBody Course course){//修改数据记录
        courseService.updateById(course);
        return Result.success();
    }

    @DeleteMapping("/delete/{id}")
    public Result delete(@PathVariable Integer id){//删除记录
        courseService.deleteById(id);
        return Result.success();
    }
}
